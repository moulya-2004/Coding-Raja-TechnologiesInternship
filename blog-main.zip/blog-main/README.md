# blog
I created a blog web page using simple HTML,CSS and js .
